DROP TABLE falecimento;

DROP TABLE nascimento;

DROP TABLE lugar_uniao;

DROP TABLE lugar;

DROP TABLE filho;

DROP TABLE uniao;

DROP TABLE pessoa;
